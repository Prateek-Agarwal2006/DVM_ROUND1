I have submitted project along with excel file from which some sample data can be loaded like code name.
I have given one section type along with sample and further section types can be loaded afterwards.
Pls change paths of file acc to ur pc.
For restricted access i have added login authentication .....username is admin ,pass is 1234 everywhere it is asked.


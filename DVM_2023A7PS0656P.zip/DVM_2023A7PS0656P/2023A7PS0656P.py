import pandas as pd
import os
from course import Course
from section import Section
from timetable import Timetable

def create_timetable_csv():
    if os.path.exists(r"c:\Users\Prateek Agarwal\Desktop\DVM\timetable.csv") :
                      print("File exsists...")
    else:
        with open(r"c:\Users\Prateek Agarwal\Desktop\DVM\timetable.csv", "w") as csv_file:
            csv_file.write("Code,Name,Section_Type,Instructor,Day,Timings")




def main():
    timetable = Timetable()

    while True:
        print("\nMenu:")
        print("1. Populate courses and sections from Excel")
        print("2. Populate sections for a specific course through CLI")
        print("3. Export timetable to CSV")
        print("4. Check for clashes")
        print("5. Exit")

        choice = input("Enter your choice (1-5): ")

        if choice == "1":
            admin=input("Username:")
            password=input("Password:")
            if timetable.login(admin,password):
                 print("Authenticated")
                 excel_filename = input("Enter Excel filename: ")
               
                 timetable.populate_course_from_excel(excel_filename)
            else :print("Sorry Invalid ID")
        elif choice == "2":
            admin=input("Username:")
            password=input("Password:")
            if timetable.login(admin,password):
                 print("Authenticated")
                 
                 course_code = input("Enter course code for section population: ")
                 selected_course = next((course for course in timetable.courses if course.code == course_code), None)
                 if selected_course:
              
                    selected_course.populate_section_cli()
                 else:
                  print("Course not found.")

        elif choice == "3":
            timetable.export_to_csv()

        elif choice == "4":
            timetable.check_clashes()

        elif choice == "5":
            print("Exiting the program.")
            break

        else:
            print("Invalid choice. Please enter a number between 1 and 5.")


main()
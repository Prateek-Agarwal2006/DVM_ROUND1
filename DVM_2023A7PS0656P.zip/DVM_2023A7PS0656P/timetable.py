import os
from course import Course
from section import Section
import pandas as pd
class Timetable:
    def __init__(self):
        self.courses = []

    def enroll_course(self, course):
        self.courses.append(course)

   
    def check_clashes(self):
        clashes = False
        for course in self.courses:
            sections = course.sections
            for i in range(len(sections)):
                for j in range(i + 1, len(sections)):
                    section1 = sections[i]
                    section2 = sections[j]

                    
                    if section1.instructor.lower()==section2.instructor.lower() and section1.day.lower() == section2.day.lower() and self.check_time_overlap(section1.start_timings,section1.end_timings, section2.start_timings,section2.end_timings):
                        print(f"Clash found in {course.name} - {section1.type} and {section2.type}")
                        clashes = True

        if not clashes:
            print("No clashes found.")

    @staticmethod
    def check_time_overlap(start_time1, end_time1, start_time2, end_time2):
        if start_time1 == start_time2:
            if end_time1 == end_time2:
                return True
            else:
                return False
        elif start_time1 < end_time2 and start_time2 < end_time1:
            return True
        else:
            return False

    def login(self,user,password):
        if user=="admin" and password=="1234":
            return True
        else : return False
            
    
        

    def export_to_csv(self):
        data = []
       
        for course in self.courses:
            for section in course.sections:
                data.append([course.code, course.name, section.type, section.instructor, section.day, section.start_timings,section.end_timings])
        
        df = pd.DataFrame(data, columns=['Code', 'Name', 'Section Type', 'Instructor', 'Day', 'Start_Timings','End_Timings'])
        print(df)
        output_path = os.path.join(r"C:\Users\Prateek Agarwal\Desktop\DVM", "timetable.csv")
        df = pd.DataFrame(data, columns=['Code', 'Name', 'Section Type', 'Instructor', 'Day', 'Start_Timings','End_Timingss'])
        df.to_csv(output_path, index=False)

        print(f"CSV exported to: {output_path}")

    def populate_course_from_excel(self, excel_filename):
        df = pd.read_csv(os.path.join(r"C:\Users\Prateek Agarwal\Desktop\DVM", excel_filename))
        for _, row in df.iterrows():
            code = str(row['Code'])
            name = row['Name']
            section_type = row['Section_Type']
            instructor = row['Instructor']
            day = row['Day']
            start_timings = row['Start_Timings']
            end_timings=row['End_Timings']
            
            existing_course = next((course for course in self.courses if course.code == code), None)
            if existing_course is None:
                new_course = Course(name, code)
                self.enroll_course(new_course)
                existing_course = new_course

            existing_course.populate_section_file(section_type, instructor, day, start_timings,end_timings)
        for course in self.courses:
            print(course)
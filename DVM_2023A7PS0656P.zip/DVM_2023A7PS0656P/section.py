class Section:
    def __init__(self, type1, instructor, day,start_timings,end_timings):
        self.type = type1
        self.instructor = instructor
        self.day = day
        self.start_timings = start_timings
        self.end_timings=end_timings
    
    def __str__(self):
        return f"{self.type} - Instructor: {self.instructor}, Day: {self.day}, Start_Timings: {self.start_timings} ,End_Timings :{self.end_timings}"


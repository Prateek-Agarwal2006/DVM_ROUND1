from section import Section
class Course:
    def __init__(self, name, code):
        self.code = code
        self.name = name
        self.sections = []

    def get_all_sections(self):
        section_available = []
        for section in self.sections:
            section_available.append(section.type)
        return section_available

    def __str__(self):
        result = f"Course name: {self.name}\nCourse code: {self.code}"
        for section in self.sections:
            result += f"\n{section}"
        return result

    def populate_section_cli(self):
        type1 = input("Enter section type: ")
        instructor = input("Enter instructor: ")
        day = input("Enter day: ")
        start_timings = int(input("Enter start_timings(Pls enter in 24 hrs format eg 13-14 without am and pm): "))
        end_timings=int(input("Enter end_timings(Pls enter in 24 hrs format eg 13-14 without am and pm): "))
        section = Section(type1, instructor, day, start_timings,end_timings)
        self.sections.append(section)

    def populate_section_file(self, type1, instructor, day, start_timings,end_timings):
        self.sections.append(Section(type1, instructor, day, start_timings,end_timings))

    def populate_section(self, type1, instructor, day, timings):
        section = Section(type1, instructor, day, timings)
        self.sections.append(section)
